#pragma once
#include "Hittable.h"

class Sphere : public Hittable
{
public:
	Sphere() = default;
	Sphere(Vector3 c, double r) : centre(c), radius(r) {};
	~Sphere() = default;

	bool Hit(const Ray& r, double tMin, double tMax, HitRecord& rec) const override;

	Vector3 centre = Vector3();
	double radius = 0;
};