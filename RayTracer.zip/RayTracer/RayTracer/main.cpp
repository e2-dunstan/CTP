#pragma once
#include "Utilities.h"
#include "HittableList.h"
#include "Sphere.h"

#include <iostream>


Vector3 RayColour(const Ray& r, const Hittable& world)
{
    HitRecord rec;
    if (world.Hit(r, 0, infinity, rec))
    {
        return (rec.normal + Vector3(1, 1, 1)) * 0.5;
    }
    else
    {
        Vector3 unitDir = r.Direction().Normalise();
        auto t = 0.5 * (unitDir.y + 1.0);
        return Vector3(1, 1, 1) * (1.0 - t) + Vector3(0.5, 0.7, 1.0) * t;
    }
}

int main()
{
	const int imgWidth = 200;
	const int imgHeight = 100;

	std::cout << "P3\n" << imgWidth << ' ' << imgHeight << "\n255\n";

    Vector3 lowerLeftCorner(-2.0, -1.0, -1.0);
    Vector3 horizontal(4.0, 0.0, 0.0);
    Vector3 vertical(0.0, 2.0, 0.0);
    Vector3 origin(0.0, 0.0, 0.0);

    HittableList world;
    world.Add(std::make_shared<Sphere>(Vector3(0, 0, -1), 0.5));
    world.Add(std::make_shared<Sphere>(Vector3(0, -100.5, -1), 100));


    for (int j = imgHeight - 1; j >= 0; --j)
    {
        std::cerr << "\rScanlines remaining: " << j << ' ' << std::flush;
        for (int i = 0; i < imgWidth; ++i)
        {
            auto u = double(i) / imgWidth;
            auto v = double(j) / imgHeight;

            Ray ray(origin, lowerLeftCorner + horizontal * u + vertical * v);
            Vector3 colour = RayColour(ray, world);

            int ir = static_cast<int>(255.999 * colour.x);
            int ig = static_cast<int>(255.999 * colour.y);
            int ib = static_cast<int>(255.999 * colour.z);
            std::cout << ir << ' ' << ig << ' ' << ib << '\n';
        }
    }
    std::cerr << "\nDone.\n";

    return 0;
}