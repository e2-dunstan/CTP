#pragma once
#include <cstdlib>
#include <limits>
#include <memory>

//#include "Ray.h"
//#include "Vector.h"

const double infinity = std::numeric_limits<double>::infinity();
const double pi = 3.1415926535897932385;

inline double DegreesToRadians(double degrees) { return degrees * pi / 180; }

inline double GetMinimum(double a, double b) { return a <= b ? a : b; }
inline double GetMaximum(double a, double b) { return a >= b ? a : b; }